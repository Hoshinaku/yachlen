<?php
/**
 * MyBB 1.8
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/about/license
 *
 */

require_once MYBB_ROOT."inc/class_xmlparser.php";

class XMLParser extends MyBBXMLParser {
}
